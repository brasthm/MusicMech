AudioFilename:tohoedm.mp3
BackgroundImage:bg2.jpg
VignetteImage:vignette.png
PreviewTime:223795
Title:Third Eye Ya!
Artist:IOSYS
Difficulty:14
Players:2
[Arena]
0,0,1000,1000
[TimingPoints]
708,689.655172413793,4,2,1,50,1,0
157951,468.75,4,2,1,40,1,0
159824,689.655172413793,4,2,2,40,1,0