AudioFilename:audio.mp3
BackgroundImage:gasg.jpg
VignetteImage:vignette.png
PreviewTime: 77597
Title:GAS GAS GAS
Artist:MANUEL
Difficulty:7
Players:4
[Arena]
360,360,280,280
[TimingPoints]
1818,389.61038961039,4,1,0,30,1,0
[Checkpoints]
0,0
35,92.1
48,132.1
70,179