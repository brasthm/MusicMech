AudioFilename:audio.mp3
PreviewTime:102983
Title:Furachi na Kassai
Artist:Police Piccadilly feat. KAFU
BackgroundImage:Screenshot_14.jpg
VignetteImage:vignette.png
Difficulty:13
Players:8
[Arena]
0,0,1000,1000
[TimingPoints]
72,379.746835443038,4,2,1,30,1,0
[Checkpoints]
[Objects]