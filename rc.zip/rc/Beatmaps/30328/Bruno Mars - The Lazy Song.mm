AudioFilename:Bruno Mars - The Lazy Song.mp3
BackgroundImage:bg.jpg
VignetteImage:vignette.png
PreviewTime:56580
Title:The Lazy Song
Artist:Bruno Mars
Difficulty:1
Players:1
[Arena]
0,0,1000,1000
[TimingPoints]
7588,685.714285714286,4,2,0,60,1,0