AudioFilename:Paramore - Still Into You.mp3
BackgroundImage:background.jpg
VignetteImage:vignette.png
PreviewTime:112076
Title:Still Into You
Artist:Paramore
Difficulty:9
Players:2
[Arena]
0,0,1000,1000
[TimingPoints]
900,441.176470588235,4,2,1,55,1,0
