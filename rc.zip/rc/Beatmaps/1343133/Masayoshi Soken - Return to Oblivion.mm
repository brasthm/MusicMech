AudioFilename:audio.mp3
PreviewTime:104154
Title:Return to Oblivion
Artist:Masayoshi Soken
BackgroundImage:Final-Fantasy-XIV-Shiva-scaled-1200x720.jpg
VignetteImage:vignette.png
Difficulty:9
Players:4
[Arena]
0,0,1000,1000
[TimingPoints]
770,461.538461538462,4,2,0,60,1,0
[Checkpoints]
0,0
40,96.1
66,144.1
100,220.1
130,292
