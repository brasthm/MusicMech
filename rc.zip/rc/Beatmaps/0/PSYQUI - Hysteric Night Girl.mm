AudioFilename:Hysteric Night Girl.mp3
BackgroundImage:background.jpg
VignetteImage:vignette.png
PreviewTime:1002
Title:Hysteric Night Girl (Tutorial)
Artist:PSYQUI
Difficulty:1
Players:4
[Arena]
0,0,1000,1000
[TimingPoints]
1969,476.190476190476,4,2,1,55,1,0
[Arena]
0,0,1000,1000
[TimingPoints]
1969,476.19,4,2,1,60,1,0
[Checkpoints]
0,0
17,33
32,64.1
48,97
57,128