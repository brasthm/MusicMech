AudioFilename:audio.mp3
PreviewTime:47744
Title:Cloud Nine
Artist:Owl City
BackgroundImage:bg.jpg
VignetteImage:vignette.png
Difficulty:2
Players:4
[Arena]
0,0,1000,1000
[TimingPoints]
2392,714.286,4,2,1,60,1,0
[Checkpoints]
0,0
9,16
33,50
43,64
66,96
90,130
100,144
123,176
145,208