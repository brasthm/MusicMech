AudioFilename:audio.ogg
PreviewTime:105070
Title:Doggy god's street
Artist:Inugami Korone
BackgroundImage:dog.png
VignetteImage:vignette.png
Difficulty:15
Players:4
[Arena]
0,0,400,1000
600,0,400,1000
[TimingPoints]
539,468.75,4,1,0,50,1,0
[Checkpoints]
0,0
10,27
25,64
40,96.1
70,160.1
85,192
100,224.1
130,288.1
145,323