AudioFilename:audio.mp3
BackgroundImage:bgalex.jpg
VignetteImage:vignette.png
PreviewTime:111396
Title:Metal - Brute Justice Mode
Artist:Masayoshi Soken
Difficulty:8
Players:4
[Arena]
0,0,1000,1000
[TimingPoints]
3438,422.535211267606,4,1,0,75,1,0
[Checkpoints]
0,0
12,32.1
25,64.1
51,128.1
64,160.1
81,192.1
81,256.1