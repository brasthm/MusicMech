AudioFilename:audio.mp3
PreviewTime:454
Title:Adieu, to this Lively Graveyard
Artist:Akatsuki Records
BackgroundImage:adieu.jpg
VignetteImage:vignette.png
Difficulty:4
Players:4
[Arena]
0,0,1000,1000
[TimingPoints]
2802,521.739,4,2,1,60,1,0
[Checkpoints]
0,0
14,31
30,64
39,79
60,112
76,152
85,167
103,200
135,264
144,280